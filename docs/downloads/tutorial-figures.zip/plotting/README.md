# Published tutorial figures

Activate the pinned tutorial environment, then run:

```bash
python plotting/reproduce_all_figures.py --case all --output-dir figures/all
```

Cases: atacama, motus, cocoa, or all. The archive includes the audited
QIIME-derived artifacts and extracted tables, original generators/helpers, and
26 reference PDFs. No statistical models are fitted. Original source hashes
are verified before running; only path-string constants in temporary copies
are relocated. Existing inputs and reference figures are never overwritten.

Each output PDF receives its own provenance JSON. The overall provenance lists
verified source hashes and relocated execution-copy hashes. Rendering may vary
slightly with fonts/backend; published website PDFs remain the originals.
The archived historical scripts are retained for provenance but are not run
by this figure-only entry point.
