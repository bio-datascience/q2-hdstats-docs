"""Reproduce published figures with preserved generators and QIIME-derived data."""
from pathlib import Path
import argparse
import ast
import hashlib
import json
import os
import shutil
import subprocess
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class Relocate(ast.NodeTransformer):
    def __init__(self, roots):
        self.roots = roots

    def visit_Constant(self, node):
        if isinstance(node.value, str):
            for old, new in self.roots.items():
                if node.value == old or node.value.startswith(old + '/'):
                    return ast.copy_location(ast.Constant(new + node.value[len(old):]), node)
        return node


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle-dir', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--case', choices=('all', 'atacama', 'motus', 'cocoa'), default='all')
    args = parser.parse_args()
    bundle, output = args.bundle_dir.resolve(), args.output_dir.resolve()
    if output.exists() and any(output.iterdir()):
        raise SystemExit('Choose an empty output directory; source snapshots are never overwritten.')
    output.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((bundle / 'figure-manifest.json').read_text())
    for row in manifest['files']:
        assert digest(bundle / row['file']) == row['sha256'], 'Source/input hash mismatch: ' + row['file']
    work = output / '.work'
    shutil.copytree(bundle / 'snapshot', work / 'snapshot')
    roots = {old: str(work / 'snapshot' / name) for old, name in manifest['roots'].items()}
    adapted = []
    for path in (work / 'snapshot').rglob('*.py'):
        before = path.read_text()
        tree = ast.parse(before)
        tree = Relocate(roots).visit(tree)
        ast.fix_missing_locations(tree)
        path.write_text(ast.unparse(tree) + '\n')
        adapted.append({'file': str(path.relative_to(work)), 'original_sha256': hashlib.sha256(before.encode()).hexdigest(),
                        'execution_sha256': digest(path), 'change': 'AST string constants containing original source-root paths only.'})
    selected = [r for r in manifest['figures'] if args.case == 'all' or
                (args.case == 'atacama' and int(r['id'][1:]) <= 16) or
                (args.case == 'motus' and 17 <= int(r['id'][1:]) <= 23) or
                (args.case == 'cocoa' and int(r['id'][1:]) >= 24)]
    for row in selected:
        path = work / row['original_output']
        if path.exists():
            path.unlink()
    canonical = work / 'snapshot/canonical'
    audit = work / 'snapshot/audit-project'
    common = canonical / 'outputs/fresh-atacama-workflow/tutorial-figure-generation'
    for case in ('motus-merged', 'bracken-beans'):
        for folder in ('exports', 'figures', 'provenance'):
            (audit / 'outputs' / case / folder).mkdir(parents=True, exist_ok=True)
    first_output = output / '.first-three'
    first_output.mkdir()
    env = os.environ.copy()
    env.update(MPLBACKEND='Agg', XDG_CACHE_HOME=str(output / '.cache'), MPLCONFIGDIR=str(output / '.cache/matplotlib'),
               NUMBA_CACHE_DIR=str(output / '.cache/numba'), ATACAMA_PROJECT_ROOT=str(canonical),
               PYTHONPATH=os.pathsep.join((str(common), str(audit / 'outputs/tutorial-figure-generation'))))
    logs = output / 'logs'
    logs.mkdir()
    groups = {}
    for row in selected:
        groups.setdefault(row['generator'], []).append(row)
    for relative, rows in groups.items():
        script = work / relative
        name = script.name
        code = f'import runpy; d=runpy.run_path({str(script)!r}, run_name="_portable_plot")\n'
        commands = []
        if name == 'replot_first_three.py':
            code += f'from pathlib import Path; out=Path({str(first_output)!r})\n'
            code += 'd["figure_s1"](out); d["figure_s2"](out); d["figure_s3"](out, selection_threshold=1/3)\n'
            commands = [[sys.executable, '-c', code]]
        elif name == 'plot_top15_classo_qiime_figures.py':
            code += 'p=d["OUT"]; f=d["plot_regression_three_panel"]\n'
            code += 'f("R3 CV", p/"atacama-top15-elevation-r1-r3-train-test-predictions.tsv", p/"atacama-top15-elevation-r1-r3-train-test-metrics.tsv", p/"atacama-top15-elevation-r1-r3-cv-coefficients.tsv", "coefficient", "atacama-top15-elevation-r3-cv-two-asv-three-panel-coefficients-in-oos", "q2-classo R3 CV refit, top-15 elevation model")\n'
            code += 'f("R3 stabsel q4 threshold 1/3", p/"atacama-top15-elevation-r3-stabsel-threshold-third-train-test-predictions.tsv", p/"atacama-top15-elevation-r3-stabsel-threshold-third-train-test-metrics.tsv", p/"atacama-top15-elevation-r3-stabsel-threshold-third-coefficients.tsv", "stabsel_refit_beta", "atacama-top15-r3-stabsel-threshold-third-three-panel-coefficients-in-oos", "q2-classo R3 stability-selection refit, top-15 elevation model")\n'
            code += 'd["plot_vegetation"]()\n'
            commands = [[sys.executable, '-c', code]]
        elif name == 'plot_motus_slc_trac_tutorial_figures.py':
            commands = [[sys.executable, str(script), method] for method in ('slc', 'trac')]
        else:
            commands = [[sys.executable, str(script)]]
        print('Rendering ' + ', '.join(r['id'] for r in rows), flush=True)
        for i, command in enumerate(commands):
            with (logs / (name + f'.{i}.log')).open('w') as log:
                result = subprocess.run(command, env=env, cwd=script.parent, stdout=log, stderr=subprocess.STDOUT)
            if result.returncode:
                raise SystemExit(f'Plotting failed: {logs / (name + f".{i}.log")}')
    outputs = []
    for row in selected:
        source = first_output / Path(row['original_output']).name if int(row['id'][1:]) <= 3 else work / row['original_output']
        assert source.is_file(), 'Generator did not produce ' + str(source)
        target = output / (row['id'] + '-' + Path(row['reference']).name)
        shutil.copy2(source, target)
        record = {'id': row['id'], 'pdf': target.name, 'sha256': digest(target), 'reference': row['reference'],
                  'reference_sha256': digest(bundle / row['reference']), 'source_manifest_sha256': digest(bundle / 'figure-manifest.json'),
                  'generator': row['generator'], 'model_fitting': False}
        target.with_suffix('.provenance.json').write_text(json.dumps(record, indent=2) + '\n')
        outputs.append(record)
    (output / 'reproduction.provenance.json').write_text(json.dumps({
        'source_manifest_sha256': digest(bundle / 'figure-manifest.json'), 'python': sys.version,
        'model_fitting': False, 'source_files_verified': len(manifest['files']),
        'generators': adapted, 'outputs': outputs}, indent=2) + '\n')
    print(f'Reproduced {len(outputs)} figures without fitting models; provenance saved in {output}.', flush=True)


if __name__ == '__main__':
    main()
