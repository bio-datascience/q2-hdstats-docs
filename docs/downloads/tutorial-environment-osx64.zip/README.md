# Tested tutorial environment

Tested in a new, isolated Intel macOS (osx-64) environment. This is not a claim
of clean-hardware or cross-platform validation. Conda package builds and the
statistical backend/plugin Git commits are pinned. The two pip compatibility
pins satisfy the QIIME runtime requirements; solver versions are unchanged.

With micromamba installed, run from this directory:

```bash
micromamba create -n q2-hdstats-tutorial --file conda-osx-64-explicit.txt
micromamba activate q2-hdstats-tutorial
python -m pip install --no-deps --no-build-isolation -r requirements-plugins.txt
python -m pip check
qiime info
```

Use this environment for both QIIME commands and optional Python figures.
Do not install c-lasso from PyPI in place of the pinned GitHub source.
For Linux or ARM-native environments, use an appropriate QIIME 2 distribution;
this platform-specific explicit file is not a cross-platform environment file.
